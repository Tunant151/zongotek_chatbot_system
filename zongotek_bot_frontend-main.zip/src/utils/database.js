/**
 * Database utility functions for fetching data from JSON files
 */

const BASE_URL = '/database'

/**
 * Generic function to fetch JSON data
 * @param {string} filename - The JSON filename without extension
 * @returns {Promise<any>} The parsed JSON data
 */
export const fetchJsonData = async (filename) => {
  try {
    const response = await fetch(`${BASE_URL}/${filename}.json`)
    if (!response.ok) {
      throw new Error(`Failed to fetch ${filename}: ${response.statusText}`)
    }
    return await response.json()
  } catch (error) {
    console.error(`Error fetching ${filename}:`, error)
    throw error
  }
}

/**
 * Fetch users data
 * @returns {Promise<Array>} Array of users
 */
export const fetchUsers = async () => {
  const data = await fetchJsonData('users')
  return data.users || []
}

/**
 * Fetch chat flows data
 * @returns {Promise<Object>} Chat flows object with flows and sample responses
 */
export const fetchChatFlows = async () => {
  return await fetchJsonData('chatFlows')
}

/**
 * Fetch tickets data
 * @returns {Promise<Array>} Array of tickets
 */
export const fetchTickets = async () => {
  const data = await fetchJsonData('tickets')
  return data.tickets || []
}

/**
 * Fetch departments data
 * @returns {Promise<Array>} Array of departments
 */
export const fetchDepartments = async () => {
  const data = await fetchJsonData('departments')
  return data.departments || []
}

/**
 * Fetch customers data
 * @returns {Promise<Array>} Array of customers
 */
export const fetchCustomers = async () => {
  const data = await fetchJsonData('customers')
  return data.customers || []
}

/**
 * Fetch chat flow templates data
 * @returns {Promise<Array>} Array of chat flow templates
 */
export const fetchChatFlowTemplates = async () => {
  const data = await fetchJsonData('chatFlowTemplates')
  return data.templates || []
}

/**
 * Fetch settings data
 * @returns {Promise<Object>} Settings object
 */
export const fetchSettings = async () => {
  return await fetchJsonData('settings')
}

/**
 * Find a user by username and password (for authentication)
 * @param {string} username - The username
 * @param {string} password - The password
 * @returns {Promise<Object|null>} User object or null if not found
 */
export const authenticateUser = async (username, password) => {
  const users = await fetchUsers()
  return users.find(user => 
    user.username === username && user.password === password
  ) || null
}

/**
 * Find a user by ID
 * @param {string} userId - The user ID
 * @returns {Promise<Object|null>} User object or null if not found
 */
export const findUserById = async (userId) => {
  const users = await fetchUsers()
  return users.find(user => user.id === userId) || null
}

/**
 * Find tickets by status
 * @param {string} status - The ticket status
 * @returns {Promise<Array>} Array of tickets with the specified status
 */
export const findTicketsByStatus = async (status) => {
  const tickets = await fetchTickets()
  return tickets.filter(ticket => ticket.status === status)
}

/**
 * Find tickets by department
 * @param {string} departmentId - The department ID
 * @returns {Promise<Array>} Array of tickets for the specified department
 */
export const findTicketsByDepartment = async (departmentId) => {
  const tickets = await fetchTickets()
  return tickets.filter(ticket => ticket.departmentId === departmentId)
}

/**
 * Find tickets by agent
 * @param {string} agentId - The agent ID
 * @returns {Promise<Array>} Array of tickets assigned to the specified agent
 */
export const findTicketsByAgent = async (agentId) => {
  const tickets = await fetchTickets()
  return tickets.filter(ticket => ticket.agentId === agentId)
}

/**
 * Find a department by ID
 * @param {string} departmentId - The department ID
 * @returns {Promise<Object|null>} Department object or null if not found
 */
export const findDepartmentById = async (departmentId) => {
  const departments = await fetchDepartments()
  return departments.find(dept => dept.id === departmentId) || null
}

/**
 * Find a customer by ID
 * @param {string} customerId - The customer ID
 * @returns {Promise<Object|null>} Customer object or null if not found
 */
export const findCustomerById = async (customerId) => {
  const customers = await fetchCustomers()
  return customers.find(customer => customer.id === customerId) || null
}

/**
 * Get chat flow by ID
 * @param {string} flowId - The flow ID
 * @returns {Promise<Object|null>} Chat flow object or null if not found
 */
export const getChatFlowById = async (flowId) => {
  const data = await fetchChatFlows()
  return data.chatFlows.find(flow => flow.id === flowId) || null
}

/**
 * Get initial chat flow
 * @returns {Promise<Object|null>} Initial chat flow object or null if not found
 */
export const getInitialChatFlow = async () => {
  const data = await fetchChatFlows()
  return data.chatFlows.find(flow => flow.isInitial === true) || data.chatFlows[0] || null
}

/**
 * Get chat flow templates by category
 * @param {string} category - The template category
 * @returns {Promise<Array>} Array of templates in the specified category
 */
export const getChatFlowTemplatesByCategory = async (category) => {
  const templates = await fetchChatFlowTemplates()
  return templates.filter(template => template.category === category)
}

/**
 * Get public chat flow templates
 * @returns {Promise<Array>} Array of public templates
 */
export const getPublicChatFlowTemplates = async () => {
  const templates = await fetchChatFlowTemplates()
  return templates.filter(template => template.isPublic === true)
}

/**
 * Calculate ticket metrics
 * @returns {Promise<Object>} Object containing various ticket metrics
 */
export const getTicketMetrics = async () => {
  const tickets = await fetchTickets()
  const users = await fetchUsers()
  
  const totalTickets = tickets.length
  const pendingTickets = tickets.filter(t => t.status === 'pending').length
  const activeTickets = tickets.filter(t => t.status === 'picked').length
  const closedTickets = tickets.filter(t => t.status === 'closed').length
  
  // Calculate closed today
  const today = new Date().toISOString().split('T')[0]
  const closedToday = tickets.filter(t => 
    t.status === 'closed' && t.closedAt && t.closedAt.startsWith(today)
  ).length
  
  // Calculate average wait time (simplified)
  const avgWaitTime = tickets.length > 0 ? 
    Math.round(tickets.reduce((acc, ticket) => {
      if (ticket.pickedAt && ticket.createdAt) {
        const waitTime = new Date(ticket.pickedAt) - new Date(ticket.createdAt)
        return acc + (waitTime / (1000 * 60)) // Convert to minutes
      }
      return acc
    }, 0) / tickets.length) : 0
  
  return {
    totalTickets,
    pendingTickets,
    activeTickets,
    closedTickets,
    closedToday,
    avgWaitTime,
    totalAgents: users.filter(u => u.role === 'agent').length
  }
}
