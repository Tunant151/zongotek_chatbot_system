/**
 * ChatFlow Data Model
 * 
 * This file defines the data structure for the customizable chatbot system.
 * It includes models for chat flows, questions, answers, conditions, and actions.
 */

/**
 * ChatFlow Model
 * Represents a complete chat flow with questions, answers, and conditions
 */
export const createChatFlow = (name, description = '') => {
  return {
    id: `flow_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
    name,
    description,
    status: 'inactive', // 'active' or 'inactive'
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    questions: [],
    startQuestionId: null
  }
}

/**
 * Question Model
 * Represents a single question in the chat flow
 */
export const createQuestion = (text, position = { x: 0, y: 0 }) => {
  return {
    id: `question_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
    text,
    position,
    answers: [],
    conditions: [],
    type: 'text' // 'text', 'input', 'multiple_choice'
  }
}

/**
 * Answer Model
 * Represents a possible answer to a question
 */
export const createAnswer = (text) => {
  return {
    id: `answer_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
    text,
    actions: [],
    isPrimary: false,
    isSecondary: false
  }
}

/**
 * Condition Model
 * Represents a condition that determines if a question should be asked
 */
export const createCondition = (type, value) => {
  return {
    id: `condition_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
    type, // 'language', 'location', 'previous_interaction', 'custom'
    value,
    operator: 'equals' // 'equals', 'not_equals', 'contains', 'not_contains', etc.
  }
}

/**
 * Action Model
 * Represents an action to be performed when an answer is selected
 */
export const createAction = (type, payload = {}) => {
  return {
    id: `action_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
    type, // 'send_message', 'navigate_to_question', 'redirect_to_url', 'transfer_to_agent'
    payload
  }
}

/**
 * Helper functions for managing chat flows
 */

// Add a question to a chat flow
export const addQuestionToChatFlow = (chatFlow, question) => {
  const updatedChatFlow = { ...chatFlow }
  updatedChatFlow.questions = [...updatedChatFlow.questions, question]
  
  // If this is the first question, set it as the start question
  if (!updatedChatFlow.startQuestionId && updatedChatFlow.questions.length === 1) {
    updatedChatFlow.startQuestionId = question.id
  }
  
  updatedChatFlow.updatedAt = new Date().toISOString()
  return updatedChatFlow
}

// Add an answer to a question
export const addAnswerToQuestion = (question, answer) => {
  return {
    ...question,
    answers: [...question.answers, answer]
  }
}

// Add a condition to a question
export const addConditionToQuestion = (question, condition) => {
  return {
    ...question,
    conditions: [...question.conditions, condition]
  }
}

// Add an action to an answer
export const addActionToAnswer = (answer, action) => {
  return {
    ...answer,
    actions: [...answer.actions, action]
  }
}

// Update a chat flow's status
export const updateChatFlowStatus = (chatFlow, status) => {
  return {
    ...chatFlow,
    status,
    updatedAt: new Date().toISOString()
  }
}

// Find a question by ID in a chat flow
export const findQuestionById = (chatFlow, questionId) => {
  return chatFlow.questions.find(question => question.id === questionId)
}

// Convert chat flow to runtime format (compatible with existing chatFlows.js)
export const convertChatFlowToRuntime = (chatFlow) => {
  const runtimeFlows = {}
  
  // Process each question into a flow
  chatFlow.questions.forEach(question => {
    const flowOptions = question.answers.map(answer => {
      // Get the first navigate action, if any
      const navigateAction = answer.actions.find(action => 
        action.type === 'navigate_to_question'
      )
      
      return {
        text: answer.text,
        nextFlow: navigateAction ? navigateAction.payload.questionId : null,
        action: navigateAction ? 'navigate' : 'message',
        isPrimary: answer.isPrimary,
        isSecondary: answer.isSecondary,
        ...(answer.actions.find(a => a.type === 'transfer_to_agent')
          ? { department: answer.actions.find(a => a.type === 'transfer_to_agent').payload.department }
          : {})
      }
    })
    
    runtimeFlows[question.id] = {
      id: question.id,
      message: question.text,
      type: 'bot',
      options: flowOptions
    }
  })
  
  return runtimeFlows
}