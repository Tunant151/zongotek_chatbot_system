import { v4 as uuidv4 } from 'uuid';

/**
 * Creates a new empty chat flow with default values
 * @returns {Object} A new chat flow object
 */
export function createNewChatFlow() {
  const id = uuidv4();
  const now = new Date().toISOString();
  
  return {
    id,
    name: 'New Chat Flow',
    description: '',
    status: 'inactive',
    createdAt: now,
    updatedAt: now,
    questions: [
      // Create an initial welcome question
      {
        id: `q_${uuidv4()}`,
        text: 'Welcome! How can I help you today?',
        type: 'text',
        isInitial: true,
        position: { x: 250, y: 100 },
        answers: [
          {
            id: `a_${uuidv4()}`,
            text: 'Learn more about your services',
            isPrimary: true,
            isSecondary: false,
            actions: [
              {
                id: `action_${uuidv4()}`,
                type: 'send_message',
                payload: {
                  message: 'We offer a wide range of services. Please ask about any specific area you\'re interested in.'
                }
              }
            ]
          },
          {
            id: `a_${uuidv4()}`,
            text: 'Talk to an agent',
            isPrimary: false,
            isSecondary: true,
            actions: [
              {
                id: `action_${uuidv4()}`,
                type: 'transfer_to_agent',
                payload: {
                  department: 'sales'
                }
              }
            ]
          }
        ]
      }
    ]
  };
}

/**
 * Validates a chat flow structure
 * @param {Object} flow - The chat flow to validate
 * @returns {Object} Validation result with isValid and errors
 */
export function validateChatFlow(flow) {
  const errors = [];
  
  // Check required fields
  if (!flow.id) errors.push('Flow ID is required');
  if (!flow.name) errors.push('Flow name is required');
  if (!Array.isArray(flow.questions) || flow.questions.length === 0) {
    errors.push('Flow must have at least one question');
  }
  
  // Check that there's an initial question
  const hasInitialQuestion = flow.questions?.some(q => q.isInitial);
  if (!hasInitialQuestion) errors.push('Flow must have an initial question');
  
  // Check that all questions have at least one answer
  const questionsWithoutAnswers = flow.questions?.filter(q => 
    !Array.isArray(q.answers) || q.answers.length === 0
  );
  
  if (questionsWithoutAnswers?.length > 0) {
    errors.push(`${questionsWithoutAnswers.length} questions have no answers`);
  }
  
  return {
    isValid: errors.length === 0,
    errors
  };
}

/**
 * Convert chat flow to runtime format (compatible with existing chatFlows.js)
 * @param {Object} chatFlow - The chat flow to convert
 * @returns {Object} Runtime format of the chat flow
 */
export function convertChatFlowToRuntime(chatFlow) {
  const runtimeFlows = {};
  
  // Process each question into a flow
  chatFlow.questions.forEach(question => {
    const flowOptions = question.answers.map(answer => {
      // Handle different action types
      let nextFlow = null;
      let action = 'message';
      let additionalProps = {};
      
      if (answer.actions && answer.actions.length > 0) {
        // Get the first action (for now, we'll handle multiple actions later)
        const firstAction = answer.actions[0];
        
        switch (firstAction.type) {
          case 'navigate_to_question':
            nextFlow = firstAction.payload.questionId;
            action = 'navigate';
            break;
          case 'send_message':
            action = 'message';
            additionalProps.message = firstAction.payload.message || answer.text;
            break;
          case 'transfer_to_agent':
            action = 'transfer';
            additionalProps.department = firstAction.payload.department || 'operations';
            break;
          case 'redirect_to_url':
            action = 'url';
            additionalProps.url = firstAction.payload.url;
            break;
          default:
            action = 'message';
            additionalProps.message = answer.text;
        }
      } else {
        // Fallback for old format
        action = answer.action?.type || 'message';
        nextFlow = answer.action?.nextFlow || null;
        additionalProps = {
          ...(answer.action?.type === 'transfer' ? { department: answer.action.department } : {}),
          ...(answer.action?.type === 'message' ? { message: answer.action.message } : {}),
          ...(answer.action?.type === 'url' ? { url: answer.action.url } : {})
        };
      }
      
      return {
        text: answer.text,
        value: nextFlow || answer.id, // Use nextFlow as value for navigation
        nextFlow: nextFlow,
        action: action,
        isPrimary: answer.isPrimary || false,
        isSecondary: answer.isSecondary || false,
        ...additionalProps
      };
    });
    
    runtimeFlows[question.id] = {
      id: question.id,
      message: question.text,
      type: 'bot',
      options: flowOptions,
      isInitial: question.isInitial || false
    };
  });
  
  return runtimeFlows;
}