// Chat flow configuration for the chatbot
export const chatFlows = {
  welcome: {
    id: 'welcome',
    message: "👋\n\nHi, let us know if you have any questions.",
    type: 'bot',
    options: []
  },

  welcome_navigation: {
    id: 'welcome_navigation',
    message: "",
    type: 'bot',
    options: [
      {
        text: "Chat now",
        nextFlow: 'it_solutions',
        action: 'navigate',
        isPrimary: true
      },
      {
        text: "Just browsing",
        nextFlow: 'general',
        action: 'navigate',
        isSecondary: true
      },
      {
        text: "Call us",
        nextFlow: 'contact',
        action: 'navigate',
        isPrimary: true
      },
      {
        text: "Email",
        nextFlow: 'email_info',
        action: 'navigate',
        isPrimary: true
      },
      {
        text: "Fax",
        nextFlow: 'contact',
        action: 'navigate',
        isPrimary: true
      }
    ]
  },

  sales: {
    id: 'sales',
    message: "Great! I can help you with sales and pricing information. What would you like to know?",
    type: 'bot',
    options: [
      {
        text: "💰 Pricing Plans",
        nextFlow: 'pricing',
        action: 'navigate'
      },
      {
        text: "🎯 Features",
        nextFlow: 'features',
        action: 'navigate'
      },
      {
        text: "📞 Schedule Demo",
        nextFlow: 'demo',
        action: 'navigate'
      },
      {
        text: "👨‍💼 Talk to Sales Team",
        nextFlow: 'transfer',
        action: 'transfer',
        department: 'sales'
      }
    ]
  },

  pricing: {
    id: 'pricing',
    message: "Here are our pricing plans:\n\n💎 **Premium Plan**: $99/month\n- All features included\n- 24/7 support\n- Custom integrations\n\n🚀 **Starter Plan**: $29/month\n- Basic features\n- Email support\n- Standard integrations\n\nWould you like to know more about any specific plan?",
    type: 'bot',
    options: [
      {
        text: "💎 Premium Plan Details",
        nextFlow: 'premium_details',
        action: 'navigate'
      },
      {
        text: "🚀 Starter Plan Details",
        nextFlow: 'starter_details',
        action: 'navigate'
      },
      {
        text: "📞 Get Custom Quote",
        nextFlow: 'transfer',
        action: 'transfer',
        department: 'sales'
      },
      {
        text: "🔙 Back to Sales",
        nextFlow: 'sales',
        action: 'navigate'
      }
    ]
  },

  technical: {
    id: 'technical',
    message: "I'm here to help with technical support. What issue are you experiencing?",
    type: 'bot',
    options: [
      {
        text: "🔧 Setup & Installation",
        nextFlow: 'setup',
        action: 'navigate'
      },
      {
        text: "🐛 Bug Report",
        nextFlow: 'bug_report',
        action: 'navigate'
      },
      {
        text: "📚 Documentation",
        nextFlow: 'docs',
        action: 'navigate'
      },
      {
        text: "👨‍💻 Talk to Tech Support",
        nextFlow: 'transfer',
        action: 'transfer',
        department: 'technical'
      }
    ]
  },

  general: {
    id: 'general',
    message: "I can provide general information about Zongotek. What would you like to know?",
    type: 'bot',
    options: [
      {
        text: "🏢 About Us",
        nextFlow: 'about',
        action: 'navigate'
      },
      {
        text: "📍 Contact Information",
        nextFlow: 'contact',
        action: 'navigate'
      },
      {
        text: "📅 Business Hours",
        nextFlow: 'hours',
        action: 'navigate'
      },
      {
        text: "👨‍💼 Talk to Operations",
        nextFlow: 'transfer',
        action: 'transfer',
        department: 'operations'
      }
    ]
  },

  transfer: {
    id: 'transfer',
    message: "I'm transferring you to a live agent. Please wait while I connect you...",
    type: 'bot',
    options: [],
    action: 'transfer'
  },

  // Additional flows for specific topics
  premium_details: {
    id: 'premium_details',
    message: "💎 **Premium Plan** includes:\n\n✅ Unlimited users\n✅ Advanced analytics\n✅ Custom integrations\n✅ Priority support\n✅ Dedicated account manager\n✅ API access\n✅ White-label options\n\nReady to get started?",
    type: 'bot',
    options: [
      {
        text: "🚀 Start Free Trial",
        nextFlow: 'trial',
        action: 'navigate'
      },
      {
        text: "📞 Talk to Sales",
        nextFlow: 'transfer',
        action: 'transfer',
        department: 'sales'
      },
      {
        text: "🔙 Back to Pricing",
        nextFlow: 'pricing',
        action: 'navigate'
      }
    ]
  },

  starter_details: {
    id: 'starter_details',
    message: "🚀 **Starter Plan** includes:\n\n✅ Up to 5 users\n✅ Basic analytics\n✅ Standard integrations\n✅ Email support\n✅ Mobile app\n✅ Basic reporting\n\nPerfect for small teams!",
    type: 'bot',
    options: [
      {
        text: "🚀 Start Free Trial",
        nextFlow: 'trial',
        action: 'navigate'
      },
      {
        text: "📞 Talk to Sales",
        nextFlow: 'transfer',
        action: 'transfer',
        department: 'sales'
      },
      {
        text: "🔙 Back to Pricing",
        nextFlow: 'pricing',
        action: 'navigate'
      }
    ]
  },

  trial: {
    id: 'trial',
    message: "🎉 Great choice! To start your free trial, I'll need to connect you with our sales team. They'll help you set up your account and answer any questions.",
    type: 'bot',
    options: [
      {
        text: "📞 Connect Now",
        nextFlow: 'transfer',
        action: 'transfer',
        department: 'sales'
      },
      {
        text: "📧 Send Email",
        nextFlow: 'email_info',
        action: 'navigate'
      },
      {
        text: "🔙 Back to Plans",
        nextFlow: 'pricing',
        action: 'navigate'
      }
    ]
  },

  setup: {
    id: 'setup',
    message: "🔧 **Setup & Installation Guide**\n\n1. Download the installer\n2. Run the setup wizard\n3. Configure your settings\n4. Import your data\n5. Start using Zongotek!\n\nNeed help with any specific step?",
    type: 'bot',
    options: [
      {
        text: "📥 Download Guide",
        nextFlow: 'download_guide',
        action: 'navigate'
      },
      {
        text: "👨‍💻 Get Help",
        nextFlow: 'transfer',
        action: 'transfer',
        department: 'technical'
      },
      {
        text: "🔙 Back to Support",
        nextFlow: 'technical',
        action: 'navigate'
      }
    ]
  },

  about: {
    id: 'about',
    message: "🏢 **About Zongotek**\n\nWe're a leading technology company focused on providing innovative solutions for businesses worldwide. Founded in 2020, we've helped thousands of companies streamline their operations.\n\nOur mission is to make technology accessible and powerful for everyone.",
    type: 'bot',
    options: [
      {
        text: "👥 Our Team",
        nextFlow: 'team',
        action: 'navigate'
      },
      {
        text: "📈 Our Story",
        nextFlow: 'story',
        action: 'navigate'
      },
      {
        text: "🔙 Back to General",
        nextFlow: 'general',
        action: 'navigate'
      }
    ]
  },

  contact: {
    id: 'contact',
    message: "📍 **Contact Information**\n\n📧 Email: info@zongotek.com\n📞 Phone: +1 (555) 123-4567\n🏢 Address: 123 Tech Street, Silicon Valley, CA\n🌐 Website: www.zongotek.com\n\nBusiness Hours: Mon-Fri 9AM-6PM PST",
    type: 'bot',
    options: [
      {
        text: "📞 Call Us",
        nextFlow: 'transfer',
        action: 'transfer',
        department: 'operations'
      },
      {
        text: "📧 Send Email",
        nextFlow: 'email_info',
        action: 'navigate'
      },
      {
        text: "🔙 Back to General",
        nextFlow: 'general',
        action: 'navigate'
      }
    ]
  },

  // New main navigation flows
  it_solutions: {
    id: 'it_solutions',
    message: "Zongotek IT Solutions delivers end-to-end technology services to keep your business secure, connected, and efficient. From managed IT and cybersecurity to cloud, automation, communications, and deployment — we provide the complete IT backbone your business needs to thrive.",
    type: 'bot',
    options: []
  },

  it_solutions_services: {
    id: 'it_solutions_services',
    message: "Tap any service below to explore more.",
    type: 'bot',
    options: [
      {
        text: "Managed IT",
        nextFlow: 'managed_it',
        action: 'navigate'
      },
      {
        text: "Network Management",
        nextFlow: 'network_management',
        action: 'navigate'
      },
      {
        text: "Cybersecurity",
        nextFlow: 'cybersecurity',
        action: 'navigate'
      },
      {
        text: "Cloud Solutions",
        nextFlow: 'cloud_solutions',
        action: 'navigate'
      },
      {
        text: "AI & Automation",
        nextFlow: 'ai_automation',
        action: 'navigate'
      },
      {
        text: "Helpdesk",
        nextFlow: 'helpdesk',
        action: 'navigate'
      },
      {
        text: "IT Consulting",
        nextFlow: 'it_consulting',
        action: 'navigate'
      },
      {
        text: "Communication",
        nextFlow: 'communication',
        action: 'navigate'
      },
      {
        text: "IT Hardware",
        nextFlow: 'it_hardware',
        action: 'navigate'
      },
      {
        text: "IT Deployment",
        nextFlow: 'it_deployment',
        action: 'navigate'
      }
    ]
  },

  it_solutions_end: {
    id: 'it_solutions_end',
    message: "Great! Glad I could help. Would you like to explore other services?",
    type: 'bot',
    options: [
      {
        text: "Yes",
        nextFlow: 'welcome_navigation',
        action: 'navigate'
      },
      {
        text: "No",
        nextFlow: 'live_agent_prompt',
        action: 'navigate'
      }
    ]
  },

  education: {
    id: 'education',
    message: "Zongotek Education provides globally recognized IT and professional training programs – from certifications and cybersecurity to communication and media literacy.",
    type: 'bot',
    options: []
  },

  education_programs: {
    id: 'education_programs',
    message: "Tap any program below to explore more.",
    type: 'bot',
    options: [
      {
        text: "IT Certifications",
        nextFlow: 'it_certifications',
        action: 'navigate'
      },
      {
        text: "Computer Hardware",
        nextFlow: 'computer_hardware',
        action: 'navigate'
      },
      {
        text: "Software Support",
        nextFlow: 'software_support',
        action: 'navigate'
      },
      {
        text: "Cybersecurity",
        nextFlow: 'education_cybersecurity',
        action: 'navigate'
      },
      {
        text: "Programming",
        nextFlow: 'programming',
        action: 'navigate'
      },
      {
        text: "IT Logic",
        nextFlow: 'it_logic',
        action: 'navigate'
      },
      {
        text: "Citizenship",
        nextFlow: 'citizenship',
        action: 'navigate'
      },
      {
        text: "Communication",
        nextFlow: 'education_communication',
        action: 'navigate'
      },
      {
        text: "Media Literacy",
        nextFlow: 'media_literacy',
        action: 'navigate'
      },
      {
        text: "Career Paths",
        nextFlow: 'career_paths',
        action: 'navigate'
      },
      {
        text: "Help Desk",
        nextFlow: 'education_helpdesk',
        action: 'navigate'
      }
    ]
  },

  education_end: {
    id: 'education_end',
    message: "Great! Glad I could help. Would you like to explore other services?",
    type: 'bot',
    options: [
      {
        text: "Yes",
        nextFlow: 'welcome_navigation',
        action: 'navigate'
      },
      {
        text: "No",
        nextFlow: 'live_agent_prompt',
        action: 'navigate'
      }
    ]
  },

  estore: {
    id: 'estore',
    message: "Shop the Zongotek E-Store for trusted brands, software, and office essentials.",
    type: 'bot',
    options: []
  },

  estore_categories: {
    id: 'estore_categories',
    message: "Tap a category below to explore more.",
    type: 'bot',
    options: [
      {
        text: "Apple",
        nextFlow: 'apple_products',
        action: 'navigate'
      },
      {
        text: "Microsoft",
        nextFlow: 'microsoft_products',
        action: 'navigate'
      },
      {
        text: "Dell",
        nextFlow: 'dell_products',
        action: 'navigate'
      },
      {
        text: "HP",
        nextFlow: 'hp_products',
        action: 'navigate'
      },
      {
        text: "Lenovo",
        nextFlow: 'lenovo_products',
        action: 'navigate'
      },
      {
        text: "Samsung",
        nextFlow: 'samsung_products',
        action: 'navigate'
      },
      {
        text: "OnePlus",
        nextFlow: 'oneplus_products',
        action: 'navigate'
      },
      {
        text: "Software",
        nextFlow: 'software_products',
        action: 'navigate'
      },
      {
        text: "SecureCam",
        nextFlow: 'securecam_products',
        action: 'navigate'
      },
      {
        text: "Office",
        nextFlow: 'office_products',
        action: 'navigate'
      }
    ]
  },

  estore_end: {
    id: 'estore_end',
    message: "Great! Glad I could help. Would you like to explore other services?",
    type: 'bot',
    options: [
      {
        text: "Yes",
        nextFlow: 'welcome_navigation',
        action: 'navigate'
      },
      {
        text: "No",
        nextFlow: 'live_agent_prompt',
        action: 'navigate'
      }
    ]
  },

  goodbye: {
    id: 'goodbye',
    message: "Thank you for visiting Zongotek! Have a great day! 👋",
    type: 'bot',
    options: []
  },

  live_agent_prompt: {
    id: 'live_agent_prompt',
    message: "I notice you've reached the end of our automated assistance. Would you like to be redirected to a live agent for further assistance?",
    type: 'bot',
    options: [
      {
        text: "Yes, connect me",
        nextFlow: 'live_agent_transfer',
        action: 'navigate'
      },
      {
        text: "No, thank you",
        nextFlow: 'goodbye',
        action: 'navigate'
      }
    ]
  },

  live_agent_transfer: {
    id: 'live_agent_transfer',
    message: "Connecting you to a live agent...",
    type: 'system',
    options: [],
    isTransferring: true
  }
}

// Helper function to get flow by ID
export const getFlow = (flowId) => {
  return chatFlows[flowId] || chatFlows.welcome
}

// Helper function to get initial flow
export const getInitialFlow = () => {
  return chatFlows.welcome
}

// Helper function to check if flow has transfer action
export const isTransferFlow = (flow) => {
  return flow.action === 'transfer' || flow.options.some(option => option.action === 'transfer')
}

// Helper function to get department from flow
export const getDepartmentFromFlow = (flow) => {
  const transferOption = flow.options.find(option => option.action === 'transfer')
  return transferOption?.department || 'operations'
}
