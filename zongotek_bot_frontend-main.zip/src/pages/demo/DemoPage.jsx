import React from 'react'
import DemoPageComponent from '@/components/demo/DemoPage'

const DemoPage = () => {
  return <DemoPageComponent />
}

export default DemoPage
