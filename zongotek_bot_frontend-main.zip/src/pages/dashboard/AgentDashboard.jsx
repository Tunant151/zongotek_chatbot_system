import React from 'react'
import AgentDashboardComponent from '@/components/dashboard/AgentDashboard'

const AgentDashboard = () => {
  return <AgentDashboardComponent />
}

export default AgentDashboard
