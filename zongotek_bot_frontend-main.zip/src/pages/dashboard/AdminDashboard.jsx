import React from 'react'
import AdminDashboardComponent from '@/components/dashboard/AdminDashboard'

const AdminDashboard = () => {
  return <AdminDashboardComponent />
}

export default AdminDashboard
