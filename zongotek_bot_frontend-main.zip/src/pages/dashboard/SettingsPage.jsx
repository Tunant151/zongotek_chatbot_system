import React from 'react'
import AdminDashboardComponent from '@/components/dashboard/AdminDashboard'

const SettingsPage = () => {
  return <AdminDashboardComponent />
}

export default SettingsPage
