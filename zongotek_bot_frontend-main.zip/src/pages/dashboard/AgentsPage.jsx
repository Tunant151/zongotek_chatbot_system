import React from 'react'
import AdminDashboardComponent from '@/components/dashboard/AdminDashboard'

const AgentsPage = () => {
  return <AdminDashboardComponent />
}

export default AgentsPage
