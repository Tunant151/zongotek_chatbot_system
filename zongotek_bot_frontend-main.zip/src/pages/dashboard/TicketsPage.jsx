import React from 'react'
import AdminDashboardComponent from '@/components/dashboard/AdminDashboard'

const TicketsPage = () => {
  return <AdminDashboardComponent />
}

export default TicketsPage
