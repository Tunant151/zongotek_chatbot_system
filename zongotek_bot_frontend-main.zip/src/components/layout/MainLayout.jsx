import React, { useState } from 'react'
import { useTheme } from '@/context/ThemeContext'
import { useAuth } from '@/context/AuthContext'
import { Link, useLocation } from 'react-router-dom'
import { 
  Settings, 
  Home, 
  MessageSquare, 
  Users, 
  Ticket, 
  LogOut, 
  Menu, 
  X, 
  Moon, 
  Sun,
  ChevronDown
} from 'lucide-react'

const MainLayout = ({ children }) => {
  const { theme, themes, setTheme, toggleDarkMode, isDarkMode } = useTheme()
  const { user, logout } = useAuth()
  const location = useLocation()
  const [sidebarOpen, setSidebarOpen] = useState(true)
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  
  // Check if current path matches the given path
  const isActive = (path) => {
    return location.pathname === path
  }

  // Toggle sidebar on desktop
  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen)
  }

  // Toggle mobile menu
  const toggleMobileMenu = () => {
    setMobileMenuOpen(!mobileMenuOpen)
  }
  
  // Define the system sections for navigation
  const systemSections = [
    { id: 'dashboard', name: 'Dashboard', path: '/', icon: <Home size={18} /> },
    { id: 'chatflow', name: 'Chat Flow Builder', path: '/chatflow', icon: <MessageSquare size={18} />, adminOnly: true },
    { id: 'agents', name: 'Agents', path: '/agents', icon: <Users size={18} />, adminOnly: true },
    { id: 'tickets', name: 'Tickets', path: '/tickets', icon: <Ticket size={18} /> },
    { id: 'settings', name: 'Settings', path: '/settings', icon: <Settings size={18} /> },
  ]

  return (
    <div className="min-h-screen bg-base-100 flex">
      {/* Sidebar - Desktop */}
      <aside 
        className={`bg-base-200 border-r border-base-300 h-screen sticky top-0 transition-all duration-300 hidden md:block ${sidebarOpen ? 'w-64' : 'w-20'}`}
      >
        <div className="p-4 flex items-center justify-between">
          {sidebarOpen ? (
            <div className="flex items-center">
              <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center text-primary-content mr-2">
                <span className="font-bold">Z</span>
              </div>
              <h1 className="text-xl font-bold">Zongotek</h1>
            </div>
          ) : (
            <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center text-primary-content mx-auto">
              <span className="font-bold">Z</span>
            </div>
          )}
          <button 
            onClick={toggleSidebar} 
            className="btn btn-sm btn-ghost btn-square"
          >
            <Menu size={18} />
          </button>
        </div>

        <div className="mt-4">
          <ul className="menu menu-md">
            {systemSections.map((section) => {
              // Skip admin-only sections for non-admin users
              if (section.adminOnly && user?.role !== 'admin') return null;
              
              return (
                <li key={section.id}>
                  <Link 
                    to={section.path} 
                    className={`${isActive(section.path) ? 'active' : ''}`}
                    title={section.name}
                  >
                    {section.icon}
                    {sidebarOpen && <span>{section.name}</span>}
                  </Link>
                </li>
              );
            })}
          </ul>
        </div>

        {/* Theme Selector */}
        {sidebarOpen && (
          <div className="absolute bottom-20 left-0 right-0 p-4">
            <div className="dropdown dropdown-top w-full">
              <div tabIndex={0} role="button" className="btn btn-outline btn-sm w-full">
                <Settings size={16} className="mr-2" />
                Theme
                <ChevronDown size={16} />
              </div>
              <ul tabIndex={0} className="dropdown-content z-[1] menu p-2 shadow bg-base-100 rounded-box w-52 max-h-60 overflow-y-auto">
                {themes.map(themeName => (
                  <li key={themeName}>
                    <button
                      onClick={() => setTheme(themeName)}
                      className={`capitalize ${theme === themeName ? 'active' : ''}`}
                    >
                      {themeName}
                    </button>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        )}

        {/* User Info */}
        <div className="absolute bottom-0 left-0 right-0 p-4 border-t border-base-300">
          {sidebarOpen ? (
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <div className="avatar placeholder mr-2">
                  <div className="bg-neutral text-neutral-content rounded-full w-8">
                    <span>{user?.name?.charAt(0) || 'U'}</span>
                  </div>
                </div>
                <div>
                  <p className="font-medium text-sm">{user?.name || 'User'}</p>
                  <p className="text-xs opacity-70 capitalize">{user?.role || 'User'}</p>
                </div>
              </div>
              <button 
                onClick={logout} 
                className="btn btn-ghost btn-sm btn-square"
                title="Logout"
              >
                <LogOut size={18} />
              </button>
            </div>
          ) : (
            <div className="flex flex-col items-center gap-2">
              <div className="avatar placeholder">
                <div className="bg-neutral text-neutral-content rounded-full w-8">
                  <span>{user?.name?.charAt(0) || 'U'}</span>
                </div>
              </div>
              <button 
                onClick={logout} 
                className="btn btn-ghost btn-sm btn-square"
                title="Logout"
              >
                <LogOut size={18} />
              </button>
            </div>
          )}
        </div>
      </aside>

      {/* Mobile Menu Button */}
      <div className="md:hidden fixed top-4 left-4 z-50">
        <button 
          onClick={toggleMobileMenu} 
          className="btn btn-primary btn-circle"
        >
          {mobileMenuOpen ? <X size={20} /> : <Menu size={20} />}
        </button>
      </div>

      {/* Mobile Sidebar */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-40 md:hidden">
          <div className="bg-base-100 w-64 h-full overflow-y-auto">
            <div className="p-4 flex items-center justify-between border-b border-base-300">
              <div className="flex items-center">
                <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center text-primary-content mr-2">
                  <span className="font-bold">Z</span>
                </div>
                <h1 className="text-xl font-bold">Zongotek</h1>
              </div>
              <button 
                onClick={toggleMobileMenu} 
                className="btn btn-sm btn-ghost btn-square"
              >
                <X size={18} />
              </button>
            </div>

            <div className="mt-4">
              <ul className="menu menu-md p-2">
                {systemSections.map((section) => {
                  // Skip admin-only sections for non-admin users
                  if (section.adminOnly && user?.role !== 'admin') return null;
                  
                  return (
                    <li key={section.id}>
                      <Link 
                        to={section.path} 
                        className={`${isActive(section.path) ? 'active' : ''}`}
                        onClick={toggleMobileMenu}
                      >
                        {section.icon}
                        <span>{section.name}</span>
                      </Link>
                    </li>
                  );
                })}
              </ul>
            </div>

            {/* Theme Controls */}
            <div className="p-4 border-t border-base-300">
              <div className="flex items-center justify-between">
                <span className="font-medium">Dark Mode</span>
                <button 
                  onClick={toggleDarkMode} 
                  className="btn btn-circle btn-sm"
                >
                  {isDarkMode ? <Sun size={16} /> : <Moon size={16} />}
                </button>
              </div>
              
              <div className="dropdown dropdown-top w-full mt-4">
                <div tabIndex={0} role="button" className="btn btn-outline btn-sm w-full">
                  <Settings size={16} className="mr-2" />
                  Theme
                  <ChevronDown size={16} />
                </div>
                <ul tabIndex={0} className="dropdown-content z-[1] menu p-2 shadow bg-base-100 rounded-box w-52 max-h-60 overflow-y-auto">
                  {themes.map(themeName => (
                    <li key={themeName}>
                      <button
                        onClick={() => setTheme(themeName)}
                        className={`capitalize ${theme === themeName ? 'active' : ''}`}
                      >
                        {themeName}
                      </button>
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            {/* User Info */}
            <div className="absolute bottom-0 left-0 right-0 p-4 border-t border-base-300">
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <div className="avatar placeholder mr-2">
                    <div className="bg-neutral text-neutral-content rounded-full w-8">
                      <span>{user?.name?.charAt(0) || 'U'}</span>
                    </div>
                  </div>
                  <div>
                    <p className="font-medium text-sm">{user?.name || 'User'}</p>
                    <p className="text-xs opacity-70 capitalize">{user?.role || 'User'}</p>
                  </div>
                </div>
                <button 
                  onClick={logout} 
                  className="btn btn-ghost btn-sm btn-square"
                  title="Logout"
                >
                  <LogOut size={18} />
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Main Content */}
      <div className="flex-1 flex flex-col min-h-screen">
        {/* Top Navigation */}
        <header className="bg-base-100 border-b border-base-300 sticky top-0 z-30">
          <div className="container mx-auto px-4 py-3 flex justify-between items-center">
            <h2 className="text-lg font-bold">
              {location.search.includes('mode=chatflow') 
                ? 'Chat Flow Builder' 
                : isActive('/agents')
                ? 'Agents Management'
                : isActive('/tickets')
                ? 'Tickets Management'
                : isActive('/settings')
                ? 'Settings'
                : 'Dashboard'}
            </h2>
            <div className="flex items-center gap-2">
              <button 
                onClick={toggleDarkMode} 
                className="btn btn-sm btn-ghost btn-circle"
                title={isDarkMode ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
              >
                {isDarkMode ? <Sun size={18} /> : <Moon size={18} />}
              </button>
            </div>
          </div>
        </header>

        {/* Page Content */}
        <main className="flex-1 p-4">
          <div className="container mx-auto">
            {children}
          </div>
        </main>

        {/* Footer */}
        <footer className="bg-base-200 border-t border-base-300 py-4">
          <div className="container mx-auto px-4 text-center text-sm text-base-content/70">
            &copy; {new Date().getFullYear()} Zongotek. All rights reserved.
          </div>
        </footer>
      </div>
    </div>
  )
}

export default MainLayout