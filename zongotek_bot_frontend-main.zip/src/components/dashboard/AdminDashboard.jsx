import React, { useState } from 'react'
import { useAuth } from '@/context/AuthContext'
import { useTickets } from '@/context/TicketContext'
import { Button } from '@/components/ui/button'
import { 
  LogOut, 
  Users, 
  MessageSquare, 
  BarChart3, 
  Settings,
  Plus,
  Trash2,
  Edit,
  Bot
} from 'lucide-react'

const AdminDashboardComponent = () => {
  const { user, logout, agents, addAgent, updateAgent, removeAgent } = useAuth()
  const { tickets, departments, setDepartments, metrics } = useTickets()
  
  const [activeTab, setActiveTab] = useState('overview')
  const [showAddAgent, setShowAddAgent] = useState(false)
  const [showAddDepartment, setShowAddDepartment] = useState(false)

  const pendingTickets = tickets.filter(t => t.status === 'pending')
  const activeTickets = tickets.filter(t => t.status === 'picked')
  const closedTickets = tickets.filter(t => t.status === 'closed')

  return (
    <div className="min-h-screen bg-base-200">
      {/* Header */}
      <header className="bg-base-100 border-b border-base-300">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <h1 className="text-2xl font-bold text-base-content">
                Admin Dashboard
              </h1>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-success"></div>
                <span className="text-sm text-base-content/70">System Admin</span>
              </div>
            </div>
            
            <div className="flex items-center gap-4">
              <div className="text-right">
                <p className="text-sm text-base-content/70">Welcome back,</p>
                <p className="font-semibold">{user?.name}</p>
              </div>
              <Button variant="outline" onClick={logout}>
                <LogOut size={16} className="mr-2" />
                Logout
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Navigation Tabs */}
        <div className="flex gap-2 mb-6">
          <Button
            variant={activeTab === 'overview' ? 'default' : 'outline'}
            onClick={() => setActiveTab('overview')}
          >
            <BarChart3 size={16} className="mr-2" />
            Overview
          </Button>
          <Button
            variant={activeTab === 'agents' ? 'default' : 'outline'}
            onClick={() => setActiveTab('agents')}
          >
            <Users size={16} className="mr-2" />
            Agents
          </Button>
          <Button
            variant={activeTab === 'tickets' ? 'default' : 'outline'}
            onClick={() => setActiveTab('tickets')}
          >
            <MessageSquare size={16} className="mr-2" />
            Tickets
          </Button>
          <Button
            variant={activeTab === 'departments' ? 'default' : 'outline'}
            onClick={() => setActiveTab('departments')}
          >
            <Settings size={16} className="mr-2" />
            Departments
          </Button>
          <Button
            variant="outline"
            onClick={() => window.location.href = '/?mode=chatflow'}
          >
            <Bot size={16} className="mr-2" />
            Chat Flow Builder
          </Button>
        </div>

        {/* Tab Content */}
        {activeTab === 'overview' && <OverviewTab metrics={metrics} />}
        {activeTab === 'agents' && <AgentsTab agents={agents} onAddAgent={addAgent} onUpdateAgent={updateAgent} onRemoveAgent={removeAgent} />}
        {activeTab === 'tickets' && <TicketsTab tickets={tickets} />}
        {activeTab === 'departments' && <DepartmentsTab departments={departments} setDepartments={setDepartments} />}
      </div>
    </div>
  )
}

// Overview Tab Component
const OverviewTab = ({ metrics }) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {/* Metrics Cards */}
      <div className="bg-base-100 rounded-lg p-6 border border-base-300">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm text-base-content/70">Active Agents</p>
            <p className="text-2xl font-bold">{metrics.totalAgents}</p>
          </div>
          <Users className="text-primary" size={24} />
        </div>
      </div>

      <div className="bg-base-100 rounded-lg p-6 border border-base-300">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm text-base-content/70">Pending Tickets</p>
            <p className="text-2xl font-bold">{metrics.pendingTickets}</p>
          </div>
          <MessageSquare className="text-warning" size={24} />
        </div>
      </div>

      <div className="bg-base-100 rounded-lg p-6 border border-base-300">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm text-base-content/70">Closed Today</p>
            <p className="text-2xl font-bold">{metrics.closedToday}</p>
          </div>
          <BarChart3 className="text-success" size={24} />
        </div>
      </div>

      <div className="bg-base-100 rounded-lg p-6 border border-base-300">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm text-base-content/70">Avg Wait Time</p>
            <p className="text-2xl font-bold">{metrics.avgWaitTime}m</p>
          </div>
          <BarChart3 className="text-info" size={24} />
        </div>
      </div>
    </div>
  )
}

// Agents Tab Component
const AgentsTab = ({ agents, onAddAgent, onUpdateAgent, onRemoveAgent }) => {
  const [newAgent, setNewAgent] = useState({
    username: '',
    name: '',
    email: '',
    departmentId: '',
    role: 'agent'
  })

  const handleAddAgent = () => {
    onAddAgent(newAgent)
    setNewAgent({ username: '', name: '', email: '', departmentId: '', role: 'agent' })
  }

  return (
    <div className="space-y-6">
      {/* Add Agent Form */}
      <div className="bg-base-100 rounded-lg p-6 border border-base-300">
        <h2 className="text-lg font-semibold mb-4">Add New Agent</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <input
            type="text"
            placeholder="Username"
            value={newAgent.username}
            onChange={(e) => setNewAgent({ ...newAgent, username: e.target.value })}
            className="px-3 py-2 border border-base-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
          />
          <input
            type="text"
            placeholder="Full Name"
            value={newAgent.name}
            onChange={(e) => setNewAgent({ ...newAgent, name: e.target.value })}
            className="px-3 py-2 border border-base-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
          />
          <input
            type="email"
            placeholder="Email"
            value={newAgent.email}
            onChange={(e) => setNewAgent({ ...newAgent, email: e.target.value })}
            className="px-3 py-2 border border-base-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
          />
          <select
            value={newAgent.departmentId}
            onChange={(e) => setNewAgent({ ...newAgent, departmentId: e.target.value })}
            className="px-3 py-2 border border-base-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
          >
            <option value="">Select Department</option>
            <option value="sales">Sales</option>
            <option value="operations">Operations</option>
            <option value="technical">Technical</option>
          </select>
        </div>
        <Button onClick={handleAddAgent} className="mt-4">
          <Plus size={16} className="mr-2" />
          Add Agent
        </Button>
      </div>

      {/* Agents List */}
      <div className="bg-base-100 rounded-lg border border-base-300">
        <div className="p-6 border-b border-base-300">
          <h2 className="text-lg font-semibold">All Agents</h2>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-base-200">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-base-content/70 uppercase tracking-wider">Name</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-base-content/70 uppercase tracking-wider">Username</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-base-content/70 uppercase tracking-wider">Department</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-base-content/70 uppercase tracking-wider">Status</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-base-content/70 uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-base-300">
              {agents.map(agent => (
                <tr key={agent.id}>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div>
                      <div className="text-sm font-medium text-base-content">{agent.name}</div>
                      <div className="text-sm text-base-content/70">{agent.email}</div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-base-content">{agent.username}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-base-content capitalize">{agent.departmentId || 'General'}</td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${
                      agent.status === 'active' ? 'bg-success/20 text-success' : 'bg-error/20 text-error'
                    }`}>
                      {agent.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                    <div className="flex gap-2">
                      <Button size="sm" variant="outline">
                        <Edit size={12} />
                      </Button>
                      <Button size="sm" variant="outline" onClick={() => onRemoveAgent(agent.id)}>
                        <Trash2 size={12} />
                      </Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}

// Tickets Tab Component
const TicketsTab = ({ tickets }) => {
  return (
    <div className="bg-base-100 rounded-lg border border-base-300">
      <div className="p-6 border-b border-base-300">
        <h2 className="text-lg font-semibold">All Tickets</h2>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead className="bg-base-200">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-base-content/70 uppercase tracking-wider">ID</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-base-content/70 uppercase tracking-wider">Subject</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-base-content/70 uppercase tracking-wider">Department</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-base-content/70 uppercase tracking-wider">Status</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-base-content/70 uppercase tracking-wider">Created</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-base-300">
            {tickets.map(ticket => (
              <tr key={ticket.id}>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-base-content">#{ticket.id.slice(-8)}</td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm font-medium text-base-content">{ticket.subject}</div>
                  <div className="text-sm text-base-content/70">{ticket.description}</div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-base-content capitalize">{ticket.departmentId}</td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${
                    ticket.status === 'pending' ? 'bg-error/20 text-error' :
                    ticket.status === 'picked' ? 'bg-warning/20 text-warning' :
                    'bg-success/20 text-success'
                  }`}>
                    {ticket.status}
                  </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-base-content">
                  {new Date(ticket.createdAt).toLocaleDateString()}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}

// Departments Tab Component
const DepartmentsTab = ({ departments, setDepartments }) => {
  const [newDepartment, setNewDepartment] = useState({ name: '', color: 'primary' })

  const handleAddDepartment = () => {
    if (newDepartment.name) {
      const department = {
        id: newDepartment.name.toLowerCase().replace(/\s+/g, '_'),
        name: newDepartment.name,
        color: newDepartment.color
      }
      setDepartments([...departments, department])
      setNewDepartment({ name: '', color: 'primary' })
    }
  }

  return (
    <div className="space-y-6">
      {/* Add Department Form */}
      <div className="bg-base-100 rounded-lg p-6 border border-base-300">
        <h2 className="text-lg font-semibold mb-4">Add New Department</h2>
        <div className="flex gap-4">
          <input
            type="text"
            placeholder="Department Name"
            value={newDepartment.name}
            onChange={(e) => setNewDepartment({ ...newDepartment, name: e.target.value })}
            className="flex-1 px-3 py-2 border border-base-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
          />
          <select
            value={newDepartment.color}
            onChange={(e) => setNewDepartment({ ...newDepartment, color: e.target.value })}
            className="px-3 py-2 border border-base-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
          >
            <option value="primary">Primary</option>
            <option value="secondary">Secondary</option>
            <option value="accent">Accent</option>
            <option value="success">Success</option>
            <option value="warning">Warning</option>
            <option value="error">Error</option>
          </select>
          <Button onClick={handleAddDepartment}>
            <Plus size={16} className="mr-2" />
            Add Department
          </Button>
        </div>
      </div>

      {/* Departments List */}
      <div className="bg-base-100 rounded-lg border border-base-300">
        <div className="p-6 border-b border-base-300">
          <h2 className="text-lg font-semibold">All Departments</h2>
        </div>
        <div className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {departments.map(dept => (
              <div key={dept.id} className="p-4 border border-base-300 rounded-lg">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-semibold capitalize">{dept.name}</h3>
                    <p className="text-sm text-base-content/70">ID: {dept.id}</p>
                  </div>
                  <div className={`w-4 h-4 rounded-full bg-${dept.color}`}></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}

export default AdminDashboardComponent
