i have been tasked wih building a chatbot and a live chat ticketing system based application.

let me explain it in this way.

the project is dividded int three parts but they autometly work together.
these three pars are

- a customizzable chatbot
- a live chat ticketing system
- a customer support dashboard

The Chatbot
the chatbot will be a customizzable chatbot that can be molded easily by a drag and drop flowchat tree type of way just like how we create a chatbot in chatbot.com.

this flow chat will be a drag and drop type of way just like how we create a chatbot in chatbot.com.
how i envision it is like this a chat will be created and it will have a name and a description and a status and also created day and updated date. these chats will appear like cards and can be clicked to show the full story flow chat of that chat.
each chat will have a set of questions and answers that will be used to answer the customer questions.
each question will have a set of possible answers and each answer will have a set of actions that will be performed.
these actions can be like sending a message to the customer, redirecting the customer to a different chat, or redirecting the customer to a different page. the answers will be in form of buttons ofcourse that will be created to the chat question in the flow chat.
each question will also have a set of conditions that will be used to determine if the question should be asked or not. these conditions can be like the customer language, the customer location, or the customer previous interactions.
ofcourse each question will have a set of possible answers and each answer will have a set of actions that will be performed.

when the status of that chat is set to active then that chat will be used by the system as the default chat for the system but when we click and open the chat thought not active it goes in a test phase and we use that chat so we can test.
lets paln and implement this part first.
